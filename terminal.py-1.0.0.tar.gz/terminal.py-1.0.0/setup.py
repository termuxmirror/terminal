# setup.py

from setuptools import setup

setup(
    name='terminal.py',
    version='1.0.0',
    py_modules=['terminal'],
    install_requires=['requests'],
    author='Alexander Krefting',
    author_email='alexkreftingjob@outlook.de',
    url='https://github.com/termuxmirror/terminal',
    description='Ein einfaches Terminal-Paket für Python.',
    keywords=['Terminal'],
)
